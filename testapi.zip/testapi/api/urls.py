from django.urls import path, include
from api.views import *

urlpatterns = [
    path('', main, name='mainmenu'),
    path('<slug:path>/', mainf, name='main'),
    path('<path:path>/', mainf, name='menu'),
    path('<path:path>/', mainf, name='sub')
]