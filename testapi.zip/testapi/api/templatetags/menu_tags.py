from django import template
from api.models import MainMenu

register = template.Library()

@register.inclusion_tag('temptag.html')
def draw_menu():
    menus = MainMenu.objects.all()
    return {'menus':menus, }