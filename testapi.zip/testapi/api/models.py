from django.db import models as md
from django.urls import reverse_lazy


class MainMenu(md.Model):
    name = md.CharField(verbose_name="Name", max_length=200)
    slug = md.SlugField(verbose_name="Slug")

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse_lazy('main', kwargs={'path': self.slug})

class Menu(md.Model):
    name = md.CharField(verbose_name="Name", max_length=200)
    slug = md.SlugField(verbose_name="Slug")
    parent = md.ForeignKey('MainMenu', on_delete=md.CASCADE, verbose_name="ParentMenu")

    def __str__(self):
        return self.name


    def get_absolute_url(self):
        return reverse_lazy('menu', kwargs={'path': self.parent.slug+'/'+self.slug})

class SubMenu(md.Model):
    name = md.CharField(verbose_name="Name", max_length=200)
    slug = md.SlugField(verbose_name="Slug")
    parent = md.ForeignKey('Menu', on_delete=md.CASCADE, verbose_name="ParentMenu",)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse_lazy('sub', kwargs={'path': self.parent.parent.slug+'/'+self.parent.slug+'/'+self.slug})

# from django.db import models as md
#
# class MainMenu(md.Model):
#     name = md.CharField(verbose_name="Name", max_length=200)
#     slug = md.SlugField(verbose_name="Slug")
#
#     def __str__(self):
#         return self.name
#
# class Menu(md.Model):
#     name = md.CharField(verbose_name="Name", max_length=200)
#     slug = md.SlugField(verbose_name="Slug")
#     parent = md.ForeignKey('MainMenu', on_delete=md.CASCADE, verbose_name="ParentMenu")
#
#     def __str__(self):
#         return self.name
#
# class SubMenu(md.Model):
#     name = md.CharField(verbose_name="Name", max_length=200)
#     slug = md.SlugField(verbose_name="Slug")
#     parent = md.ForeignKey('Menu', on_delete=md.CASCADE, verbose_name="ParentMenu", )
#
#     def __str__(self):
#         return self.name