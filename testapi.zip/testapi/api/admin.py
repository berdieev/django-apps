from django.contrib import admin
from .models import *

class MainAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'slug']
    prepopulated_fields = {'slug':['name']}
    search_fields = ['name',]
    list_display_links = ['name',]
    ordering = ['name']

class MenuAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'slug', 'parent']
    prepopulated_fields = {'slug':['name']}
    search_fields = ['name',]
    list_display_links = ['name',]
    list_filter = ['parent']
    ordering = ['name']

class SubAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'slug', 'parent']
    prepopulated_fields = {'slug':['name']}
    search_fields = ['name',]
    list_display_links = ['name',]
    list_filter = ['parent']
    ordering = ['name']

admin.site.register(MainMenu, MainAdmin)
admin.site.register(Menu, MenuAdmin)
admin.site.register(SubMenu, SubAdmin)