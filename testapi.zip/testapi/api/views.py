from django.shortcuts import render
from .models import MainMenu

def main(request):
    menus = MainMenu.objects.all()
    return render(request, 'menus.html', {'menus': menus})

def mainf(request, path):
    menus = MainMenu.objects.all()
    return render(request, 'menus.html', {'menus': menus, 'path': path})